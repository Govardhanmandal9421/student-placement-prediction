from django.shortcuts import render
from joblib import load
from django.shortcuts import redirect
import os
import warnings 
from sklearn.preprocessing import StandardScaler
warnings.filterwarnings("ignore")
from sklearn.preprocessing import LabelEncoder
le = LabelEncoder()

final_model = load('./final_model/model.joblib')



def model_ml(request):

    if request.method == 'GET' and request.GET:
        try:
            # Read and convert all form inputs to float
            ssc_p                = float(request.GET.get('ssc_p', 0))
            ssc_b                = float(request.GET.get('ssc_b', 0))
            hsc_p                = float(request.GET.get('hsc_p', 0))
            hsc_s                = float(request.GET.get('hsc_s', 0))
            degree_p             = float(request.GET.get('degree_p', 0))
            degree_t             = float(request.GET.get('degree_t', 0))
            etest_p              = float(request.GET.get('etest_p', 0))
            mba_p                = float(request.GET.get('mba_p', 0))
            gender_M             = float(request.GET.get('gender_M', 0))
            hsc_b_Others         = float(request.GET.get('hsc_b_Others', 0))
            workex_Yes           = float(request.GET.get('workex_Yes', 0))
            specialisation_MktHR = float(request.GET.get('specialisation_MktHR', 0))

            # Scaler values from the dataset (approximate based on notebook analysis)
            # These are for: ssc_p, hsc_p, hsc_s, degree_p, degree_t, etest_p, mba_p
            # ssc_b is NOT scaled in notebook, so we keep it raw (0/1)
            
            means = [67.30, 66.33, 1.34, 66.37, 0.60, 72.10, 62.27]
            stds  = [10.82, 10.89, 0.65, 7.35, 0.89, 13.27, 5.83]

            # Scaling only the features that were scaled in the notebook
            s_ssc_p    = (ssc_p - means[0]) / stds[0]
            s_hsc_p    = (hsc_p - means[1]) / stds[1]
            s_hsc_s    = (hsc_s - means[2]) / stds[2]
            s_degree_p = (degree_p - means[3]) / stds[3]
            s_degree_t = (degree_t - means[4]) / stds[4]
            s_etest_p  = (etest_p - means[5]) / stds[5]
            s_mba_p    = (mba_p - means[6]) / stds[6]

            # Feature alignment MUST match notebook:
            # ['ssc_p', 'ssc_b', 'hsc_p', 'hsc_s', 'degree_p', 'degree_t', 'etest_p', 'mba_p', 'gender_M', 'hsc_b_Others', 'workex_Yes', 'specialisation_Mkt&HR']
            features = [[s_ssc_p, ssc_b, s_hsc_p, s_hsc_s, s_degree_p, s_degree_t,
                         s_etest_p, s_mba_p, gender_M, hsc_b_Others,
                         workex_Yes, specialisation_MktHR]]

            prediction = final_model.predict(features)[0]
            
            user_input = {
                'ssc percentage':  ssc_p ,
                'ssc board': ssc_b,
                'hsc percentage': hsc_p,
                'hsc stream': hsc_s,
                'degree percentage': degree_p,
                'degree type': degree_t,
                'etest percentage': etest_p,
                'mba percentage': mba_p,
                'gender': gender_M,
                'hsc board': hsc_b_Others,
                'workex': workex_Yes,
                'specialisation': specialisation_MktHR,
            }
            result = "will get Placement" if prediction == 1 else "Not get Placement"
            return render(request, 'base.html', {'result': result,
            'user_input': user_input})
 
        except Exception as e:
            error = str(e)
            print("Prediction error:", error)
            return render(request, 'base.html', {'error': error})

    return render(request, 'base.html')

def result(request):
    return render(request, 'result.html')